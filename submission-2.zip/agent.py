"""Submission template.

Edit `policy()` to generate actions from an observation.
The evaluator will import this file and call `policy(obs, rng)`.

Action space (strings): 'L45', 'L22', 'FW', 'R22', 'R45'
Observation: numpy array shape (18,), values are 0/1.
"""

from typing import Sequence
import os
import pickle
import numpy as np

ACTIONS   = ["L45", "L22", "FW", "R22", "R45"]
N_ACTIONS = len(ACTIONS)
_Q_TABLE = None

def _load_q_table():
    global _Q_TABLE
    if _Q_TABLE is not None:
        return _Q_TABLE

    this_dir = os.path.dirname(os.path.abspath(__file__))
    pkl_path = os.path.join(this_dir, "q_table.pkl")

    if os.path.exists(pkl_path):
        with open(pkl_path, "rb") as f:
            _Q_TABLE = pickle.load(f)
        print(f"[Q-Agent] Loaded Q-table: {len(_Q_TABLE)} states")
    else:
        print("[Q-Agent] WARNING: q_table.pkl not found. Using heuristic fallback.")
        _Q_TABLE = {}

    return _Q_TABLE

def _obs_to_state(obs):
    """Convert 18-bit binary observation array to integer state key."""
    bits = np.asarray(obs, dtype=np.int32)
    return int(np.dot(bits, 1 << np.arange(18, dtype=np.int32)))



def _heuristic(obs): # for when table has no entries
    
    obs = np.asarray(obs, dtype=int)

    attached  = obs[17]
    ir_sensor = obs[16]

    if attached:
        return "FW"

    if ir_sensor:
        return "FW"

    near = obs[0:8]
    far  = obs[8:16]

    if near[3] or near[2] or near[4]:
        return "FW"

    if far[3] or far[2] or far[4]:
        return "FW"

    if near[1] or near[2] or far[1] or far[2]:
        return "L22"

    if near[4] or near[5] or far[4] or far[5]:
        return "R22"

    if near[0] or far[0]:
        return "L45"

    if near[6] or far[6]:
        return "R45"

    return "R22"


def policy(obs, rng=None):
    Q = _load_q_table()
    obs = np.asarray(obs, dtype=int)
    state = _obs_to_state(obs)

    if np.max(Q[state]) == 0.0:
        return _heuristic(obs)
    else:
        # Known state: Exploit the trained Q-table
        action_idx = int(np.argmax(Q[state]))
        return ACTIONS[action_idx]