import os
import pickle
import numpy as np

ACTIONS   = ["L45", "L22", "FW", "R22", "R45"]
N_ACTIONS = len(ACTIONS)
_Q_TABLE  = None

def _load_q_table():
    global _Q_TABLE
    if _Q_TABLE is not None:
        return _Q_TABLE
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "q_table.pkl"),
        os.path.join(os.getcwd(), "q_table.pkl"),
        "q_table.pkl",
    ]
    for path in candidates:
        if os.path.exists(path):
            with open(path, "rb") as f:
                _Q_TABLE = pickle.load(f)
            return _Q_TABLE
    _Q_TABLE = np.zeros((262144, 5), dtype=np.float32)
    return _Q_TABLE

def _obs_to_state(obs):
    bits = np.asarray(obs, dtype=np.int32)
    return int(np.dot(bits, 1 << np.arange(18, dtype=np.int32)))

def _heuristic(obs):
    if obs[17]: return "L45"
    if obs[16]: return "FW"
    if np.any(obs[5:12:2]): return "FW"
    if np.any(obs[4:12:2]): return "FW"
    left  = np.any(obs[0:4])
    right = np.any(obs[12:16])
    if left and right:  return "R45"
    if left:            return "L22"
    if right:           return "R22"
    return "R22"

def policy(obs, rng=None):
    Q     = _load_q_table()
    obs   = np.asarray(obs, dtype=np.int32)
    state = _obs_to_state(obs)
    q     = Q[state] if isinstance(Q, np.ndarray) else Q.get(state, np.zeros(N_ACTIONS))
    if q.max() > 10.0:
        return ACTIONS[int(np.argmax(q))]
    return _heuristic(obs)