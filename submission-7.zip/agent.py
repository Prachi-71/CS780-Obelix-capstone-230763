import os
import torch
import torch.nn as nn
import numpy as np

ACTIONS   = ["L45", "L22", "FW", "R22", "R45"]
N_ACTIONS = 5
N_OBS     = 18

class DuelingDQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(DuelingDQN, self).__init__()
        self.feature = nn.Sequential(
            nn.Linear(input_dim, 64), nn.ReLU(),
            nn.Linear(64, 64),        nn.ReLU()
        )
        self.value_stream = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1)
        )
        self.advantage_stream = nn.Sequential(
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, output_dim)
        )

    def forward(self, x):
        f = self.feature(x)
        v = self.value_stream(f)
        a = self.advantage_stream(f)
        return v + a - a.mean(dim=1, keepdim=True)

_MODEL = None

def _load_model():
    global _MODEL
    if _MODEL is not None:
        return _MODEL
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "d3qn_weights.pth"),
        os.path.join(os.getcwd(), "d3qn_weights.pth"),
        "d3qn_weights.pth",
    ]
    for path in candidates:
        if os.path.exists(path):
            sd     = torch.load(path, map_location="cpu")
            hidden = sd["feature.0.weight"].shape[0]
            _MODEL = DuelingDQN(N_OBS, N_ACTIONS)
            # rebuild with correct hidden size
            _MODEL.feature = nn.Sequential(
                nn.Linear(N_OBS, hidden), nn.ReLU(),
                nn.Linear(hidden, hidden), nn.ReLU()
            )
            _MODEL.value_stream = nn.Sequential(
                nn.Linear(hidden, hidden//2), nn.ReLU(),
                nn.Linear(hidden//2, 1)
            )
            _MODEL.advantage_stream = nn.Sequential(
                nn.Linear(hidden, hidden//2), nn.ReLU(),
                nn.Linear(hidden//2, N_ACTIONS)
            )
            _MODEL.load_state_dict(sd)
            _MODEL.eval()
            return _MODEL
    
    _MODEL = DuelingDQN(N_OBS, N_ACTIONS)
    _MODEL.eval()
    return _MODEL

def _heuristic(obs):
    if obs[17]: return "L45"
    if obs[16]: return "FW"
    if np.any(obs[5:12:2]): return "FW"
    if np.any(obs[4:12:2]): return "FW"
    left  = np.any(obs[0:4])
    right = np.any(obs[12:16])
    if left and right:  return "R45"
    if left:            return "L22"
    if right:           return "R22"
    return "R22"

def policy(obs, rng=None):
    model = _load_model()
    obs   = np.asarray(obs, dtype=np.float32)
    with torch.no_grad():
        q_vals = model(torch.FloatTensor(obs).unsqueeze(0))
    if float(q_vals.max().item()) < 0.1:
        return _heuristic(obs)
    return ACTIONS[int(q_vals.argmax().item())]