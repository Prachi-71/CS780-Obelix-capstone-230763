import os
import torch
import torch.nn as nn
import numpy as np
from collections import deque

ACTIONS = ["L45", "L22", "FW", "R22", "R45"]

class QNetwork(nn.Module):
    def __init__(self):
        super(QNetwork, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(72, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 5)
        )

    def forward(self, x):
        return self.net(x)

my_model = None
frame_stack = None

def get_model():
    global my_model
    if my_model is not None:
        return my_model

    my_model = QNetwork()
    my_model.eval()
    
    weight_path = "nfq_weights.pth"
    abs_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), weight_path)
    
    try:
        if os.path.exists(abs_path):
            my_model.load_state_dict(torch.load(abs_path, map_location="cpu"))
        else:
            my_model.load_state_dict(torch.load(weight_path, map_location="cpu"))
    except Exception as e:
        print("Could not load NFQ weights, using random network. Error:", e)
        
    return my_model

def basic_fallback(obs):
    if obs[17] == 1.0: 
        return "L45"
    if obs[16] == 1.0: 
        return "FW"
        
    if obs[5] == 1.0 or obs[7] == 1.0 or obs[9] == 1.0:
        return "FW"
        
    left_side = sum(obs[0:4])
    right_side = sum(obs[12:16])
    
    if left_side > 0 and right_side > 0:
        return "R45"
    elif left_side > 0:
        return "L22"
    elif right_side > 0:
        return "R22"
        
    return "R22"

def policy(obs, rng=None):
    global frame_stack
    
    obs = np.array(obs, dtype=np.float32)
    
    if frame_stack is None:
        frame_stack = deque([obs for _ in range(4)], maxlen=4)
    
    frame_stack.append(obs)
    stacked_obs = np.concatenate(list(frame_stack))
    
    net = get_model()
    
    with torch.no_grad():
        tensor_obs = torch.FloatTensor(stacked_obs).unsqueeze(0)
        q_values = net(tensor_obs)
        
    max_q = float(q_values.max().item())
    if max_q == 0.0:
        return basic_fallback(obs)
        
    best_action_index = int(q_values.argmax().item())
    return ACTIONS[best_action_index]