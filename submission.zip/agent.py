import os
import numpy as np
import torch
import torch.nn as nn
from collections import deque

ACTIONS = ["L45", "L22", "FW", "R22", "R45"]

class ActorNetwork(nn.Module):
    def __init__(self, state_dim=72, action_dim=5):
        super(ActorNetwork, self).__init__()
        self.actor = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.Tanh(),
            nn.Linear(128, 64),
            nn.Tanh(),
            nn.Linear(64, action_dim),
            nn.Softmax(dim=-1)
        )
        
    def forward(self, x):
        return self.actor(x)

class PPOAgentWrapper:
    def __init__(self):
        self.device = torch.device("cpu")
        self.stack_size = 4
        self.obs_queue = deque(maxlen=self.stack_size)
        self.policy = ActorNetwork(state_dim=72, action_dim=5).to(self.device)
        
        current_dir = os.path.dirname(os.path.abspath(__file__))
        weights_path = os.path.join(current_dir, "ppo_weights.pth")
        
        if os.path.exists(weights_path):
            raw_dict = torch.load(weights_path, map_location=self.device, weights_only=False)
            
            if "actor" in raw_dict:
                self.policy.actor.load_state_dict(raw_dict["actor"])
            else:
                try:
                    self.policy.actor.load_state_dict(raw_dict)
                except RuntimeError:
                    clean_dict = {k.replace('actor.', ''): v for k, v in raw_dict.items() if k.startswith('actor.')}
                    self.policy.actor.load_state_dict(clean_dict)
                    
            self.policy.eval()
        else:
            print(f"CRITICAL ERROR: Weights file not found at {weights_path}")

    def act(self, observation):
        obs = np.asarray(observation, dtype=np.float32)
        
        if len(self.obs_queue) == 0:
            for _ in range(self.stack_size):
                self.obs_queue.append(obs)
        else:
            self.obs_queue.append(obs)
            
        state = np.concatenate(self.obs_queue)
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            action_probs = self.policy(state_tensor)
            action_idx = torch.argmax(action_probs, dim=-1).item()
            
        return ACTIONS[action_idx]

_global_agent = None

def policy(obs, rng):
    global _global_agent
    if _global_agent is None:
        _global_agent = PPOAgentWrapper()
        
    return _global_agent.act(obs)